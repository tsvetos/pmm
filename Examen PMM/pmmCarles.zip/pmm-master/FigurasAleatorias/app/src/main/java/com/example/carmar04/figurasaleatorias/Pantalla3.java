package com.example.carmar04.figurasaleatorias;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Pantalla3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla3);
    }
}
